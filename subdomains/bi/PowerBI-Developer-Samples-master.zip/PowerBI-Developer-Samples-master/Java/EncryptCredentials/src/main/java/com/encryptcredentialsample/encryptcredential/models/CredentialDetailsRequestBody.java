// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

package com.encryptcredentialsample.encryptcredential.models;

public class CredentialDetailsRequestBody {
	public CredentialDetails credentialDetails;

	public CredentialDetailsRequestBody(CredentialDetails CredentialDetails) {
		this.credentialDetails = CredentialDetails;
	}
}
