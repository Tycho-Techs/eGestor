// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

package com.encryptcredentialsample.encryptcredential.models;

public class PublicKeyConfig {
	public GatewayPublicKey publicKey;
	public String gatewayId;
}
