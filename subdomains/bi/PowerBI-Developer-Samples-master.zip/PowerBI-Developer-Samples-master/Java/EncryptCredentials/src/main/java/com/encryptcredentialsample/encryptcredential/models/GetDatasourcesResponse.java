// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

package com.encryptcredentialsample.encryptcredential.models;

import java.util.ArrayList;

public class GetDatasourcesResponse {
	public ArrayList<DatasourceConfig> value;
}
